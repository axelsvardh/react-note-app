import 'bootstrap/dist/css/bootstrap.min.css'
import React from 'react'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import List from './components/List'

function App() {
  return (
    <div>
      <Container>
        <Row>
          <Col style={{backgroundColor: 'lightblue', padding: '50px', fontSize: '40px'}} xs={12}>
            Notes
          </Col>
          <Col style={{backgroundColor: 'lightgreen'}} xs={12} md={4}>
            <Button
              variant="dark"
              size="md"
              block
              style={{marginTop: '30px', marginBottom: '10px'}}
            >
              New Note
            </Button>
            <List />
          </Col>
          <Col style={{backgroundColor: 'lightgrey'}} xs={12} md={8}>
            <Form style={{margin: '30px'}}>
              <Form.Group controlId="formGroupEmail">
                <Form.Label>Title</Form.Label>
                <Form.Control type="text" placeholder="Enter title" />
              </Form.Group>
              <Form.Group controlId="formGroupPassword">
                <Form.Label>Text</Form.Label>
                <Form.Control type="text" placeholder="Enter note" />
              </Form.Group>
            </Form>
            <Button variant="primary" style={{margin: '20px'}}>
              Save
            </Button>
            <Button variant="danger">Delete</Button>{' '}
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default App

const styles = {
  heading: {
    fontSize: 100,
  },
  underrubrik: {
    fontSize: 60,
  },
}
