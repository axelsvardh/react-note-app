// C: Create a note
// R: Read (get) a note
// U: Update a note
// D: Delete a note

const notes = [
  {id: 1, title: 'hello', body: 'hejhejhej'},
  {id: 2, title: 'another note', body: 'hallåhallåhallå'},
  {id: 3, title: 'new notes', body: 'tjenatjenatjena'},
]
// const notes = [{id: '123', title: 'another note', body: 'new note'}]

export function createNote(note) {}

export function getNotes() {
  //notes.find((element) => element.id === id)
  return notes
}

export function updateNote(id, title, body) {
  //notes.find(element => element.id === id || element => element.title )
}
